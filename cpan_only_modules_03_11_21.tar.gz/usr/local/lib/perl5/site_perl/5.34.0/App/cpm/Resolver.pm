package App::cpm::Resolver;
use strict;
use warnings;

1;
